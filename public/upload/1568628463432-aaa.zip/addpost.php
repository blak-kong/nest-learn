<?php
exit('Access Denied');
// mod文件只能被入口文件引用，不能直接访问
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
date_default_timezone_set('Asia/Shanghai');//设置时区
global $_G;

if(empty($_G['uid'])){
	showmessage('您还没有登录没法发布app,请登录后重新发布','pgapp.php');	
}
if(count($_POST)==0){
	showmessage('您还没有提交任何信息！','pgapp.php?mod=add');	
}
//print_r($_POST);

$cateid=isset($_POST['cateid'])?dhtmlspecialchars($_POST['cateid']):0;
$title=isset($_POST['title'])?dhtmlspecialchars($_POST['title']):'';
$name=isset($_POST['name'])?dhtmlspecialchars($_POST['name']):'';

$url=isset($_POST['url'])?dhtmlspecialchars($_POST['url']):'';	

$android_url=isset($_POST['android_url'])?dhtmlspecialchars($_POST['android_url']):'';	
$ios_url=isset($_POST['ios_url'])?dhtmlspecialchars($_POST['ios_url']):'';	
$wp_url=isset($_POST['wp_url'])?dhtmlspecialchars($_POST['wp_url']):'';	

$email=isset($_POST['email'])?dhtmlspecialchars($_POST['email']):'';	
$alipay=isset($_POST['alipay'])?dhtmlspecialchars($_POST['alipay']):'';
$qq=isset($_POST['qq'])?dhtmlspecialchars($_POST['qq']):'';		
$description=isset($_POST['description'])?dhtmlspecialchars($_POST['description']):'';		
$info=isset($_POST['info'])?$_POST['info']:'';
$postArray=array();
$postArray['postApp']['catid']=$cateid;
$postArray['postApp']['title']=$title;
$postArray['postApp']['name']=$name;
$postArray['postApp']['url']=$url;
$postArray['postApp']['android_url']=$android_url;
$postArray['postApp']['ios_url']=$ios_url;
$postArray['postApp']['wp_url']=$wp_url;
$postArray['postApp']['email']=$email;
$postArray['postApp']['alipay']=$alipay;
$postArray['postApp']['qq']=$qq;
$postArray['postApp']['description']=$description;
$postArray['postApp']['info']=$info;

file_put_contents('data/pgapp/postTemp_'.$_G['uid'].'.txt',serialize($postArray));
//print_r($_G);

if(empty($title)){
	showmessage('应用标题不能为空','pgapp.php?mod=add');	
}
if(empty($android_url)&&empty($wp_url)&&empty($ios_url)){
	showmessage('android应用地址或者ios应用地址或者wp应用地址 必须得填写一个','pgapp.php?mod=add');	
}
if(empty($description)){
	showmessage('应用描述不能为空','pgapp.php?mod=add');	
}
if(empty($info)){
	showmessage('应用详情不能为空','pgapp.php?mod=add');	
}
$icon=upFile('icon');
if($icon==''){
	showmessage('应用图标不能为空','pgapp.php?mod=add');	
}

$sql = "INSERT INTO ".DB::table('app_list')."
	(`name`,`title`,`uid`,`username`,`cateid`,`url`,`android_url`,`ios_url`,`wp_url`,`email`,`alipay`,
	`description`,`icon`,`qq`,`info`,`addtime`) 	
	VALUES ('".$name."'
	,'".$title."'
	,'".$_G['uid']."'
	,'".$_G['username']."'
	,'".$cateid."'
	,'".$url."'	
	,'".$android_url."'
	,'".$ios_url."'
	,'".$wp_url."'
	,'".$email."'
	,'".$alipay."'
	,'".$description."'
	,'".$icon."'
	,'".$qq."'
	,'".$info."'
	,'".time()."'
)";

DB::query($sql);
$last_id = DB::insert_id();
if($last_id){
	if(file_exists('data/pgapp/postTemp_'.$_G['uid'].'.txt')){
		@unlink('data/pgapp/postTemp_'.$_G['uid'].'.txt');
	}
	showmessage('恭喜您，添加应用成功，审核通过将在应用列表显示','pgapp.php?mod=myapp');
}else{
	showmessage('添加应用失败','pgapp.php?mod=add');
}
//上传文件方法
function upFile($fileName){
	$_files = array('image/jpeg','image/pjpeg','image/png','image/x-png','image/gif');
	//判断类型是否是数组里的一种	
	if (!in_array($_FILES[$fileName]['type'],$_files)) {
		showmessage('上传文件类型不对','pgapp.php?mod=add');	
	}
	if ($_FILES[$fileName]['size']/1024>1024) {
		showmessage('上传文件大小不能大于1M','pgapp.php?mod=add');	
	}
	//判断文件错误类型
	 if ($_FILES['userfile']['error'] > 0) {		
		showmessage('文件上传失败，请检查上传文件大小','pgapp.php?mod=add');			
	}
	
	$_n = explode('.',$_FILES[$fileName]['name']);
	//获取时间戳
	$now_time=time();//cpmiddleimg
	$return_name ='data/pgapp/'.$now_time.'.'.$_n[1];			
	//移动文件 看文件是否移动成功如果移动成功 则执行插入数据操作
	if(is_uploaded_file($_FILES[$fileName]['tmp_name'])) {
		if	(!move_uploaded_file($_FILES[$fileName]['tmp_name'],$return_name)) {
			showmessage('文件上传失败，请重试','pgapp.php?mod=add');			
		} else {
			return $return_name;
		}
	 }
}

exit;
?>
